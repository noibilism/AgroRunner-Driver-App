App.controller('recieptCtrl', function ($scope, $rootScope,$ionicHistory) {
$ionicHistory.nextViewOptions({
        disableBack: true
       });
})