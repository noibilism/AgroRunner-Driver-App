var secret_key = "fb5e77f2b23945ce9cdfa9093b457fa2";
var map_api_key="AIzaSyBoL26hVGudbJBDMo5yT3PIc-A93EX67NE";
var server_domain = 'http://agrorunner.com';
//var server_domain = 'http://192.168.1.31/shajeer/cmc_website/Source';
//var server_domain = 'http://192.168.138.31/lidiya/callmycab';
var wordpress = false;
